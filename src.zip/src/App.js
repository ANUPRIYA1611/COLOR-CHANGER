import logo from './logo.svg';
import './App.css';
import Form from './components/ca2';

function App() {
  return (
    <div className="App">
        <Form></Form>
    </div>
  );
}

export default App;
