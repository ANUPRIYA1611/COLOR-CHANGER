import React, { useState } from 'react'
import Select from 'react-select'
function Form() {
  var colors=[
    {
       value:1,
       label:"RED"
    },
    {
       value:2,
       label:"BLUE"
    },
    {
       value:3,
       label:"ORANGE"
    },
    {
       value:4,
       label:"LIGHTGREEN"
    },
    {
        value:5,
        label:"GREY"
    },
    {
        value:6,
        label:"PINK"
    },
    {
        value:7,
        label:"YELLOW"
    },
    {
        value:8,
        label:"DARKBLUE"
    },
    {
        value:9,
    label:"PURPLE"    },
    {
        value:10,
        label:"LAVENDER"
    }
  ];
  var [setbgcolor,ddlvalue]=useState(colors.label);
  var ddlhandle = (e) => {
    ddlvalue(e.label);
  }
  return (
    <>
      <h1 align="center">DROP-DOWN-COLOR</h1>
      <div className='h'>
      {}
        <Select options={colors} onChange={ddlhandle} className="sl">
        </Select>
      </div>
        <div className='drop'>
            <style>{'.drop {background-color:'+setbgcolor+';}'}</style> 
          <h3> {setbgcolor}</h3>
        </div>
    </>
  )
}
export default Form